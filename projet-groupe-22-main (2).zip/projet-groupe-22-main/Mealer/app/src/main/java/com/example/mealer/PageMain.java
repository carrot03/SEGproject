package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PageMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_main);
    }
}